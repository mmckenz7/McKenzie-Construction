# McKenzie Construction / McKenzie OS v1

A Next.js public website + owner CRM starter for **mckenzie-builds.com**.

## Included
- Modern public website focused on decks and outdoor living
- Fast lead form with photos intentionally optional
- Supabase-backed lead capture
- Owner login foundation using magic-link authentication
- CRM lead list and dashboard shell
- PWA manifest and service worker foundation for Home Screen installation and future push alerts
- Netlify deployment configuration
- SEO metadata

## 1. Supabase setup
1. Open the Supabase project: `jjvxtwqewpiddhoedwkn`.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Open **Project Settings → API**.
4. Copy the public/anon key. Never use the service-role key in browser environment variables.
5. In **Authentication → URL Configuration**, add:
   - Site URL: `https://mckenzie-builds.com`
   - Redirect URL: `https://mckenzie-builds.com/admin/dashboard`
6. In Authentication users, invite/create Michael's owner email.

## 2. Netlify environment variables
In the Netlify site `lustrous-cucurucho-679c66`, add:
- `NEXT_PUBLIC_SUPABASE_URL=https://jjvxtwqewpiddhoedwkn.supabase.co`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY=<your anon key>`
- `NEXT_PUBLIC_SITE_URL=https://mckenzie-builds.com`
- `NEXT_PUBLIC_COMPANY_EMAIL=<business email>`
- `NEXT_PUBLIC_COMPANY_PHONE=865-263-3811`

## 3. GitHub deployment
Upload this project to the GitHub repository `McKenzie-Construction` and connect that repository to Netlify. Netlify should detect Next.js and run `npm run build`.

## 4. Domain
In GoDaddy DNS, use the records Netlify provides under **Domain management → Add a domain**. Add both:
- `mckenzie-builds.com`
- `www.mckenzie-builds.com`
Set the non-www domain as primary.

## 5. Run locally
```bash
npm install
cp .env.example .env.local
npm run dev
```

## Important before launch
- Replace the temporary project image blocks with Michael's real project photography.
- Replace the placeholder accent color values if the uploaded logo uses a different exact palette.
- Add business email, license/insurance wording and verified review content.
- Add server-side auth guards before storing confidential customer or financial information.

## Next sprint
- Secure middleware/auth guards
- Lead detail/edit pages
- Follow-up dates and dashboard counts
- Optional photo uploads
- Push subscription permission flow and server notifications
- Calendar and task views
