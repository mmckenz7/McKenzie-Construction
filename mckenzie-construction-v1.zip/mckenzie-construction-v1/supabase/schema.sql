create extension if not exists "pgcrypto";

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  name text not null,
  phone text not null,
  email text,
  address text,
  project_type text,
  description text not null,
  budget text,
  timeline text,
  source text default 'Website',
  status text not null default 'new' check (status in ('new','contacted','appointment','estimate','follow_up','sold','lost')),
  next_follow_up timestamptz,
  notes text
);

alter table public.leads enable row level security;

-- Anonymous website visitors may only create leads.
create policy "public can submit leads" on public.leads for insert to anon with check (true);

-- Authenticated owner can read and update all leads.
create policy "authenticated can read leads" on public.leads for select to authenticated using (true);
create policy "authenticated can update leads" on public.leads for update to authenticated using (true) with check (true);

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  endpoint text unique not null,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions enable row level security;
create policy "users manage own subscriptions" on public.push_subscriptions for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
