'use client';
import { FormEvent, useState } from 'react';

export function LeadForm() {
  const [state, setState] = useState<'idle'|'sending'|'success'|'error'>('idle');
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setState('sending');
    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());
    const res = await fetch('/api/leads', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    setState(res.ok ? 'success' : 'error');
    if (res.ok) e.currentTarget.reset();
  }
  if (state === 'success') return <div className="card p-8"><h3 className="text-2xl font-semibold">Thanks — Michael will review this personally.</h3><p className="mt-3 text-brand-slate">You’ll hear from McKenzie Construction within one business day.</p></div>;
  return <form onSubmit={submit} className="card grid gap-4 p-6 sm:p-8">
    <div className="grid gap-4 sm:grid-cols-2">
      <label className="text-sm font-medium">Name<input required name="name" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3" /></label>
      <label className="text-sm font-medium">Phone<input required name="phone" inputMode="tel" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3" /></label>
      <label className="text-sm font-medium">Email<input name="email" type="email" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3" /></label>
      <label className="text-sm font-medium">Property address<input name="address" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3" /></label>
    </div>
    <label className="text-sm font-medium">Project type<select name="project_type" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3"><option>New deck</option><option>Deck replacement</option><option>Covered deck</option><option>Screened porch</option><option>Outdoor living</option><option>Deck repair</option><option>Not sure yet</option></select></label>
    <label className="text-sm font-medium">Tell us what you’re considering<textarea required name="description" rows={4} className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3" /></label>
    <div className="grid gap-4 sm:grid-cols-3">
      <label className="text-sm font-medium">Investment range<select name="budget" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3"><option>I'd like guidance</option><option>Under $15,000</option><option>$15,000–$30,000</option><option>$30,000–$50,000</option><option>$50,000+</option></select></label>
      <label className="text-sm font-medium">Timeline<select name="timeline" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3"><option>Just planning</option><option>ASAP</option><option>Within 3 months</option><option>This year</option></select></label>
      <label className="text-sm font-medium">How did you hear about us?<select name="source" className="mt-2 w-full rounded-xl border border-black/10 px-4 py-3"><option>Google</option><option>Facebook</option><option>Referral</option><option>Realtor</option><option>Yard sign</option><option>Other</option></select></label>
    </div>
    <p className="text-xs text-brand-slate">Photos are helpful but never required. We’ll add optional photo upload in the next sprint.</p>
    <button disabled={state==='sending'} className="btn-primary w-full sm:w-fit">{state==='sending' ? 'Sending…' : 'Request consultation'}</button>
    {state==='error' && <p className="text-sm text-red-700">Something went wrong. Please call or text us directly.</p>}
  </form>;
}
