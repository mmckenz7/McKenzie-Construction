import Link from 'next/link';

const links = [
  ['Services', '/services'], ['Projects', '/projects'], ['About', '/about'], ['Contact', '/contact']
];

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-black/5 bg-white/90 backdrop-blur-xl">
      <div className="container-shell flex h-20 items-center justify-between">
        <Link href="/" className="leading-none">
          <span className="block text-lg font-bold tracking-tight">McKenzie Construction</span>
          <span className="mt-1 block text-[10px] font-semibold uppercase tracking-[0.22em] text-brand-accent">Outdoor Living Specialists</span>
        </Link>
        <nav className="hidden items-center gap-7 md:flex">
          {links.map(([label, href]) => <Link key={href} href={href} className="text-sm font-medium text-brand-slate hover:text-black">{label}</Link>)}
          <Link href="/contact" className="btn-primary">Request a consultation</Link>
        </nav>
        <Link href="/contact" className="btn-primary md:hidden">Get a quote</Link>
      </div>
    </header>
  );
}
