import Link from 'next/link';
export function Footer() {
  return <footer className="border-t border-black/5 bg-brand-ink py-12 text-white">
    <div className="container-shell grid gap-8 md:grid-cols-3">
      <div><p className="text-xl font-semibold">McKenzie Construction</p><p className="mt-3 max-w-sm text-sm text-white/65">Custom decks, covered spaces, screened porches and complete outdoor living projects throughout East Tennessee.</p></div>
      <div className="text-sm text-white/70"><p className="font-semibold text-white">Service area</p><p className="mt-3">Knoxville • Powell • Halls • Clinton • Oak Ridge • Farragut • Hardin Valley</p></div>
      <div className="md:text-right"><Link href="/admin/login" className="text-sm text-white/45 hover:text-white">Team login</Link><p className="mt-6 text-xs text-white/35">© {new Date().getFullYear()} McKenzie Construction</p></div>
    </div>
  </footer>;
}
