self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>{
  const data=event.data?event.data.json():{title:'McKenzie OS',body:'You have a new update.'};
  event.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/icon-192.svg',badge:'/icon-192.svg',data:{url:data.url||'/admin/dashboard'}}));
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(clients.openWindow(event.notification.data?.url||'/admin/dashboard'));});
