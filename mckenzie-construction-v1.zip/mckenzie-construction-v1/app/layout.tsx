import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { PwaRegister } from '@/components/PwaRegister';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://mckenzie-builds.com'),
  title: { default: 'McKenzie Construction | Deck Builder Knoxville TN', template: '%s | McKenzie Construction' },
  description: 'Premium decks, screened porches, covered decks and outdoor living projects serving Knoxville and East Tennessee.',
  manifest: '/manifest.webmanifest',
  openGraph: { title: 'McKenzie Construction', description: 'Outdoor living designed around how you live.', type: 'website' }
};
export const viewport: Viewport = { themeColor: '#171A1D' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body><PwaRegister /><Header />{children}<Footer /></body></html>; }
