import Link from 'next/link';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { ServiceCard } from '@/components/ServiceCard';
import { LeadForm } from '@/components/LeadForm';

export default function Home() {
  return <main>
    <section className="relative overflow-hidden bg-brand-cream py-20 sm:py-28">
      <div className="container-shell grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]">
        <div><p className="kicker">Knoxville & East Tennessee</p><h1 className="h1 mt-5">Built around<br/>how you live.</h1><p className="mt-7 max-w-xl text-lg leading-8 text-brand-slate">McKenzie Construction designs and builds premium decks, covered spaces, screened porches and complete outdoor living projects.</p><div className="mt-8 flex flex-wrap gap-3"><Link href="/contact" className="btn-primary">Request a consultation <ArrowRight className="ml-2 h-4 w-4"/></Link><Link href="/projects" className="btn-secondary">View our work</Link></div></div>
        <div className="aspect-[4/3] overflow-hidden rounded-[2rem] bg-[linear-gradient(135deg,#30363B,#171A1D)] p-8 text-white shadow-soft"><div className="flex h-full flex-col justify-between"><p className="kicker text-white/55">Featured project</p><div><p className="text-3xl font-semibold">16×32 outdoor living deck</p><p className="mt-3 max-w-md text-sm leading-6 text-white/70">A full-depth entertaining deck designed for real furniture, grilling, family gatherings and a seamless connection to the backyard.</p></div></div></div>
      </div>
    </section>
    <section className="py-20"><div className="container-shell"><p className="kicker">What we build</p><h2 className="h2 mt-4 max-w-3xl">Outdoor spaces that feel like part of the home.</h2><div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4"><ServiceCard title="Composite Decks" body="Low-maintenance deck systems designed for long-term performance and a finished, premium look."/><ServiceCard title="Covered Decks" body="Shade, rain protection and architecture that makes the backyard useful more days of the year."/><ServiceCard title="Screened Porches" body="Comfortable, bug-free outdoor rooms built for East Tennessee weather and everyday use."/><ServiceCard title="Custom Outdoor Living" body="Fire features, pergolas, stairs, lighting and complete spaces designed around your property."/></div></div></section>
    <section className="bg-brand-ink py-20 text-white"><div className="container-shell grid gap-12 lg:grid-cols-2"><div><p className="kicker">Why McKenzie</p><h2 className="h2 mt-4">A contractor’s eye.<br/>A designer’s restraint.</h2><p className="mt-6 max-w-xl text-white/65">We focus on the structure, proportions and details that make an outdoor project feel intentional—not added on.</p></div><div className="grid gap-4 sm:grid-cols-2">{['Clear scopes and proposals','Built for real-world use','Premium material options','Direct owner communication'].map(x=><div key={x} className="flex gap-3 rounded-2xl border border-white/10 p-5"><CheckCircle2 className="mt-0.5 h-5 w-5 text-brand-accent"/><p className="text-sm">{x}</p></div>)}</div></div></section>
    <section className="py-20"><div className="container-shell grid gap-12 lg:grid-cols-[.8fr_1.2fr]"><div><p className="kicker">Start the conversation</p><h2 className="h2 mt-4">Tell us what you want your backyard to become.</h2><p className="mt-5 text-brand-slate">The form takes under a minute. Photos and exact dimensions are optional.</p></div><LeadForm /></div></section>
  </main>;
}
