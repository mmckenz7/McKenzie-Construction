import { NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase';
export async function POST(request: Request){
  try {
    const body = await request.json();
    if(!body.name || !body.phone || !body.description) return NextResponse.json({error:'Missing required fields'},{status:400});
    const supabase = getSupabase();
    if(!supabase) return NextResponse.json({error:'Supabase environment variables are not configured'},{status:503});
    const { error } = await supabase.from('leads').insert({
      name: body.name, phone: body.phone, email: body.email || null, address: body.address || null,
      project_type: body.project_type || null, description: body.description, budget: body.budget || null,
      timeline: body.timeline || null, source: body.source || 'Website', status: 'new'
    });
    if(error) throw error;
    return NextResponse.json({ok:true});
  } catch(error){ console.error(error); return NextResponse.json({error:'Unable to save lead'},{status:500}); }
}
