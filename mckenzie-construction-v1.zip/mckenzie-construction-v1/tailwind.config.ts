import type { Config } from 'tailwindcss';

export default {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          ink: '#171A1D',
          slate: '#30363B',
          accent: '#B78A45',
          cream: '#F5F2EC',
          mist: '#E8ECEF'
        }
      },
      boxShadow: { soft: '0 20px 60px rgba(17,24,39,.10)' }
    }
  },
  plugins: []
} satisfies Config;
